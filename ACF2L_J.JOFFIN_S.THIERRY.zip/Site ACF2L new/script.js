const faqItems = document.querySelectorAll(".faq-item");

faqItems.forEach((item) => {
  const question = item.querySelector(".faq-question");
  question.addEventListener("click", () => {
    const isOpen = item.classList.contains("open");
    faqItems.forEach((other) => {
      other.classList.remove("open");
      other.querySelector(".faq-answer").style.maxHeight = null;
    });
    if (!isOpen) {
      item.classList.add("open");
      const answer = item.querySelector(".faq-answer");
      answer.style.maxHeight = answer.scrollHeight + "px";
    }
  });
});

document.querySelectorAll('a[href^="#"]').forEach((link) => {
  link.addEventListener("click", (e) => {
    const target = document.querySelector(link.getAttribute("href"));
    if (target) {
      e.preventDefault();
      target.scrollIntoView({ behavior: "smooth" });
    }
  });
});

const revealElements = document.querySelectorAll("section .container > *, .gallery-card");

const revealObserver = new IntersectionObserver(
  (entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add("visible");
        revealObserver.unobserve(entry.target);
      }
    });
  },
  { threshold: 0.15 }
);

revealElements.forEach((el) => {
  el.classList.add("reveal");
  revealObserver.observe(el);
});

window.addEventListener("resize", () => {
  document.querySelectorAll(".faq-item.open .faq-answer").forEach((answer) => {
    answer.style.maxHeight = answer.scrollHeight + "px";
  });
});

const navLinks = document.querySelectorAll(".navbar .nav-link");
const sections = document.querySelectorAll("section[id], header[id]");

const navObserver = new IntersectionObserver(
  (entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        navLinks.forEach((link) => {
          link.classList.toggle(
            "active",
            link.getAttribute("href") === "#" + entry.target.id
          );
        });
      }
    });
  },
  { threshold: 0.4 }
);

sections.forEach((section) => navObserver.observe(section));

const form = document.getElementById("contactForm");

const faviconLink = document.getElementById("favicon");
const faviconImg = new Image();
faviconImg.crossOrigin = "anonymous";
faviconImg.src = faviconLink.href;
faviconImg.onload = () => {
  const canvas = document.createElement("canvas");
  canvas.width = faviconImg.naturalWidth;
  canvas.height = faviconImg.naturalHeight;
  const ctx = canvas.getContext("2d");
  ctx.filter = "invert(1)";
  ctx.drawImage(faviconImg, 0, 0);
  faviconLink.href = canvas.toDataURL("image/png");
};

form.addEventListener("submit", (e) => {
  e.preventDefault();
  if (!form.checkValidity()) {
    form.reportValidity();
    return;
  }
  const button = form.querySelector(".btn-submit");
  const original = button.innerHTML;
  button.innerHTML = "Envoyé ! <i class='bi bi-check2 ms-2'></i>";
  button.disabled = true;
  setTimeout(() => {
    button.innerHTML = original;
    button.disabled = false;
    form.reset();
  }, 2500);
});